export const environment = {
  production: true,
  dbUrl: '',
  webApiKey: ''
};
